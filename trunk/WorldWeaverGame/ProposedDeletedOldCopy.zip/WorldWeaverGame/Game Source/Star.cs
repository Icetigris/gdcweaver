using System;
using System.Collections.Generic;
using System.Text;

namespace WorldWeaver
{
    class Star : CelestialBody
    {
    }
}
