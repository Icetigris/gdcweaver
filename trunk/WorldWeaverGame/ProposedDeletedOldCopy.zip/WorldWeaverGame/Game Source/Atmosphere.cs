using System;
using System.Collections.Generic;
using System.Text;

namespace WorldWeaver
{
    class Atmosphere
    {
        //composition
        //volume
        //pressure
        //mass
        //atmospheric escape: bigger planet, harder for particles to escape. Also higher in planets that lack a magnetosphere
    }
}
