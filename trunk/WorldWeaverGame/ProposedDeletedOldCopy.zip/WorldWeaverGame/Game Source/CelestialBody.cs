using System;
using System.Collections.Generic;
using System.Text;

namespace WorldWeaver
{
    abstract class CelestialBody
    {
        //radius
        //mass
        //volume
        //density = mass/volume
        //surface temperature
        //gravity points
    }
}
