#region File Description
//-----------------------------------------------------------------------------
// Planet.cs
//
// World Weaver
// Elizabeth Baumel
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace WorldWeaver
{
    class Planet : CelestialBody
    {
        //has an atmosphere
        //core composition (does it have a magnetosphere?)

        public void MakePlanet(Vector3 position, Vector3 radius, MoleculePool pool)
        {
            //do some stuff
        }
    }
}
